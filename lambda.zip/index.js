const AWS  = require("aws-sdk");
exports.handler = async (event) => {
    const STS = new AWS.STS();
    const Account = await STS.getCallerIdentity({}).promise();
    console.log("ada");

    // const response = {
    //     statusCode: 200,
    //     body: JSON.stringify(Account),
    // };
    return Account.Account;
};

